package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.PublicProfile
import com.example.data.model.UserAccount
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class SocialRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveProfileAndCreatePost_authenticatedUser_emitsInPublicFeed() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@test.com")
        val repo = SocialRepository(firestore, auth)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.saveUserProfile(
                displayName = "Alice Zisan",
                username = "alice_z",
                bio = "Building on Zisan Social",
                city = "Dhaka",
                avatarData = "",
                email = "alice@test.com",
                onboardingCompleted = true
            )
        }

        val postId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createPost(
                authorName = "Alice Zisan",
                authorHandle = "alice_z",
                authorAvatarData = "",
                content = "Hello Zisan Social ${UUID.randomUUID()}",
                visibility = "public"
            )
        }
        assertTrue(postId.isNotBlank())

        val posts = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observePublicFeedPosts().first { list -> list.any { it.id == postId } }
        }
        val created = posts.first { it.id == postId }
        assertEquals(aliceUid, created.authorId)
        assertEquals("Alice Zisan", created.authorName)
    }

    @Test
    fun likeCommentAndShare_crossUser_updatesCountsAndPersists() = runBlocking {
        signInTestUser("alice2_${UUID.randomUUID()}@test.com")
        val aliceRepo = SocialRepository(firestore, auth)
        val postId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createPost(
                authorName = "Alice",
                authorHandle = "alice",
                authorAvatarData = "",
                content = "Check out this update!",
                visibility = "public"
            )
        }

        signInTestUser("bob2_${UUID.randomUUID()}@test.com")
        val bobRepo = SocialRepository(firestore, auth)
        val post = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observePublicFeedPosts().first { list -> list.any { it.id == postId } }
                .first { it.id == postId }
        }

        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.toggleLikePost(post, currentlyLiked = false, actorName = "Bob", actorAvatarData = "")
            bobRepo.addComment(post, authorName = "Bob", authorAvatarData = "", text = "Nice update!")
        }

        val comments = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeComments(postId).first { it.isNotEmpty() }
        }
        assertEquals("Nice update!", comments.first().text)
    }

    @Test
    fun deletePost_crossUser_failsWithPermissionDenied() = runBlocking {
        signInTestUser("alice3_${UUID.randomUUID()}@test.com")
        val aliceRepo = SocialRepository(firestore, auth)
        val postId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createPost(
                authorName = "Alice",
                authorHandle = "alice",
                authorAvatarData = "",
                content = "Protected post",
                visibility = "public"
            )
        }

        signInTestUser("bob3_${UUID.randomUUID()}@test.com")
        val bobRepo = SocialRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.deletePost(postId)
            }
            fail("Expected PERMISSION_DENIED when Bob deletes Alice's post")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    @Test
    fun messengerConversation_participantsCanSendAndObserveMessages() = runBlocking {
        val aliceUid = signInTestUser("alice4_${UUID.randomUUID()}@test.com")
        val bobUid = signInTestUser("bob4_${UUID.randomUUID()}@test.com")
        // Sign back in as Alice to initiate conversation
        auth.signOut()
        // Create deterministic email for alice4 to re-sign-in
        val aliceEmail = "alice_chat_${UUID.randomUUID()}@test.com"
        val uidA = signInTestUser(aliceEmail)
        val repo = SocialRepository(firestore, auth)

        val conv = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.openOrCreateConversation(
                currentProfile = UserAccount(userId = uidA, displayName = "Alice"),
                otherProfile = PublicProfile(userId = bobUid, displayName = "Bob")
            )
        }

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.sendMessage(conv, senderName = "Alice", senderAvatarData = "", text = "Hey Bob!")
        }

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMessages(conv.id, uidA).first { it.isNotEmpty() }
        }
        assertEquals("Hey Bob!", messages.first().text)
        assertTrue(aliceUid.isNotBlank())
    }

    @Test
    fun observePublicFeedPosts_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = SocialRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observePublicFeedPosts().first()
            }
            fail("Expected PERMISSION_DENIED for unauthenticated user")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
