package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.Comment
import com.example.data.model.Conversation
import com.example.data.model.Follow
import com.example.data.model.Friendship
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.PublicProfile
import com.example.data.model.Story
import com.example.data.model.UserAccount
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SocialRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun <T> Flow<T>.logFirestoreErrors(operation: OperationType, path: String, expectedUid: String? = null): Flow<T> =
        catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val exceptionToLog = firestoreError ?: (error as? Exception)
            if (exceptionToLog != null && (expectedUid == null || auth.currentUser?.uid == expectedUid)) {
                handleFirestoreError(exceptionToLog, operation, path)
            }
            throw error
        }

    // --- User Account & Public Profile ---

    fun observeUserAccount(uid: String): Flow<UserAccount?> =
        db.collection("users").document(uid)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(UserAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .logFirestoreErrors(OperationType.GET, "users/$uid", uid)

    fun observePublicProfiles(): Flow<List<PublicProfile>> =
        db.collection("public_profiles")
            .whereEqualTo("isDiscoverable", true)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.displayName.lowercase() }
            }
            .logFirestoreErrors(OperationType.LIST, "public_profiles")

    suspend fun saveUserProfile(
        displayName: String,
        username: String,
        bio: String,
        city: String,
        avatarData: String,
        email: String,
        onboardingCompleted: Boolean = true
    ) {
        val uid = requireUserId()
        val userRef = db.collection("users").document(uid)
        val publicRef = db.collection("public_profiles").document(uid)
        val cleanDisplay = displayName.trim().take(60).ifBlank { "Zisan Member" }
        val cleanHandle = username.trim().lowercase().replace(Regex("[^a-z0-9_.]"), "").take(30).ifBlank { "user_${uid.take(6)}" }
        val cleanBio = bio.trim().take(250)
        val cleanCity = city.trim().take(80)

        try {
            val existingUser = userRef.get().await()
            val batch = db.batch()
            if (!existingUser.exists()) {
                val privatePayload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to cleanDisplay,
                    "username" to cleanHandle,
                    "onboardingCompleted" to onboardingCompleted,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (email.isNotBlank()) privatePayload["email"] = email.take(200)
                if (cleanBio.isNotBlank()) privatePayload["bio"] = cleanBio
                if (cleanCity.isNotBlank()) privatePayload["city"] = cleanCity
                if (avatarData.isNotBlank()) privatePayload["avatarData"] = avatarData
                batch.set(userRef, privatePayload)
            } else {
                val updatePrivate = mutableMapOf<String, Any>(
                    "displayName" to cleanDisplay,
                    "username" to cleanHandle,
                    "bio" to cleanBio,
                    "city" to cleanCity,
                    "onboardingCompleted" to onboardingCompleted,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (email.isNotBlank()) updatePrivate["email"] = email.take(200)
                if (avatarData.isNotBlank()) updatePrivate["avatarData"] = avatarData
                batch.update(userRef, updatePrivate)
            }

            val existingPublic = publicRef.get().await()
            if (!existingPublic.exists()) {
                val publicPayload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to cleanDisplay,
                    "username" to cleanHandle,
                    "isDiscoverable" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanBio.isNotBlank()) publicPayload["bio"] = cleanBio
                if (cleanCity.isNotBlank()) publicPayload["city"] = cleanCity
                if (avatarData.isNotBlank()) publicPayload["avatarData"] = avatarData
                batch.set(publicRef, publicPayload)
            } else {
                val updatePublic = mutableMapOf<String, Any>(
                    "displayName" to cleanDisplay,
                    "username" to cleanHandle,
                    "bio" to cleanBio,
                    "city" to cleanCity,
                    "isDiscoverable" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (avatarData.isNotBlank()) updatePublic["avatarData"] = avatarData
                batch.update(publicRef, updatePublic)
            }

            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userRef.path)
            throw e
        }
    }

    // --- Posts & Feed ---

    fun observePublicFeedPosts(): Flow<List<Post>> =
        db.collection("posts")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Post::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "posts")

    fun observeUserPosts(targetUserId: String, currentUserId: String): Flow<List<Post>> {
        val query = if (targetUserId == currentUserId) {
            db.collection("posts").whereEqualTo("authorId", currentUserId)
        } else {
            db.collection("posts").whereEqualTo("visibility", "public")
        }
        return query.snapshots()
            .map { snapshot ->
                snapshot.toObjects(Post::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.authorId == targetUserId }
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "posts")
    }

    fun observeLikedPostIds(uid: String): Flow<Set<String>> =
        db.collection("users").document(uid).collection("liked_posts")
            .snapshots()
            .map { snapshot -> snapshot.documents.map { it.id }.toSet() }
            .logFirestoreErrors(OperationType.LIST, "users/$uid/liked_posts", uid)

    suspend fun createPost(
        authorName: String,
        authorHandle: String,
        authorAvatarData: String,
        content: String,
        imageData: String = "",
        feeling: String = "",
        bgColorHex: String = "",
        visibility: String = "public"
    ): String {
        val uid = requireUserId()
        val docRef = db.collection("posts").document()
        val payload = mutableMapOf<String, Any>(
            "authorId" to uid,
            "authorName" to authorName.trim().take(80).ifBlank { "Zisan User" },
            "content" to content.trim().take(5000),
            "visibility" to if (visibility == "friends") "friends" else "public",
            "likesCount" to 0L,
            "commentsCount" to 0L,
            "sharesCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (authorHandle.isNotBlank()) payload["authorHandle"] = authorHandle.take(40)
        if (authorAvatarData.isNotBlank()) payload["authorAvatarData"] = authorAvatarData
        if (imageData.isNotBlank()) payload["imageData"] = imageData
        if (feeling.isNotBlank()) payload["feeling"] = feeling.take(60)
        if (bgColorHex.isNotBlank()) payload["bgColorHex"] = bgColorHex.take(16)

        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deletePost(postId: String) {
        val uid = requireUserId()
        val docRef = db.collection("posts").document(postId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "posts/$postId (uid=$uid)")
            throw e
        }
    }

    suspend fun toggleLikePost(
        post: Post,
        currentlyLiked: Boolean,
        actorName: String,
        actorAvatarData: String
    ) {
        val uid = requireUserId()
        val postRef = db.collection("posts").document(post.id)
        val likeRef = postRef.collection("likes").document(uid)
        val userLikedRef = db.collection("users").document(uid).collection("liked_posts").document(post.id)

        try {
            val batch = db.batch()
            if (currentlyLiked) {
                batch.delete(likeRef)
                batch.delete(userLikedRef)
                batch.update(
                    postRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    likeRef,
                    mapOf(
                        "userId" to uid,
                        "userName" to actorName.take(80).ifBlank { "Someone" },
                        "postId" to post.id,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    userLikedRef,
                    mapOf(
                        "userId" to uid,
                        "postId" to post.id,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    postRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()

            if (!currentlyLiked && post.authorId != uid) {
                createNotification(
                    recipientId = post.authorId,
                    actorName = actorName,
                    actorAvatarData = actorAvatarData,
                    type = "like",
                    message = "$actorName liked your post.",
                    targetPostId = post.id
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, postRef.path)
            throw e
        }
    }

    // --- Comments ---

    fun observeComments(postId: String): Flow<List<Comment>> =
        db.collection("posts").document(postId).collection("comments")
            .whereEqualTo("postId", postId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Comment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "posts/$postId/comments")

    suspend fun addComment(
        post: Post,
        authorName: String,
        authorAvatarData: String,
        text: String
    ) {
        val uid = requireUserId()
        val trimmed = text.trim().take(1000)
        if (trimmed.isBlank()) return

        val postRef = db.collection("posts").document(post.id)
        val commentRef = postRef.collection("comments").document()
        val payload = mutableMapOf<String, Any>(
            "postId" to post.id,
            "authorId" to uid,
            "authorName" to authorName.take(80).ifBlank { "Zisan User" },
            "text" to trimmed,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (authorAvatarData.isNotBlank()) payload["authorAvatarData"] = authorAvatarData

        try {
            val batch = db.batch()
            batch.set(commentRef, payload)
            batch.update(
                postRef,
                mapOf(
                    "commentsCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            if (post.authorId != uid) {
                createNotification(
                    recipientId = post.authorId,
                    actorName = authorName,
                    actorAvatarData = authorAvatarData,
                    type = "comment",
                    message = "$authorName commented: \"${trimmed.take(60)}\"",
                    targetPostId = post.id
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            throw e
        }
    }

    // --- Share Post ---

    suspend fun sharePost(
        originalPost: Post,
        sharerName: String,
        sharerHandle: String,
        sharerAvatarData: String,
        note: String
    ): String {
        val uid = requireUserId()
        val newPostRef = db.collection("posts").document()
        val origPostRef = db.collection("posts").document(originalPost.id)
        val payload = mutableMapOf<String, Any>(
            "authorId" to uid,
            "authorName" to sharerName.take(80).ifBlank { "Zisan User" },
            "content" to note.trim().take(5000),
            "sharedPostId" to originalPost.id,
            "sharedAuthorName" to originalPost.authorName.take(80),
            "sharedContent" to originalPost.content.take(2000),
            "visibility" to "public",
            "likesCount" to 0L,
            "commentsCount" to 0L,
            "sharesCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (sharerHandle.isNotBlank()) payload["authorHandle"] = sharerHandle.take(40)
        if (sharerAvatarData.isNotBlank()) payload["authorAvatarData"] = sharerAvatarData

        try {
            val batch = db.batch()
            batch.set(newPostRef, payload)
            batch.update(
                origPostRef,
                mapOf(
                    "sharesCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            if (originalPost.authorId != uid) {
                createNotification(
                    recipientId = originalPost.authorId,
                    actorName = sharerName,
                    actorAvatarData = sharerAvatarData,
                    type = "share",
                    message = "$sharerName shared your post.",
                    targetPostId = originalPost.id
                )
            }
            return newPostRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, newPostRef.path)
            throw e
        }
    }

    // --- Stories ---

    fun observeStories(): Flow<List<Story>> =
        db.collection("stories")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Story::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "stories")

    suspend fun createStory(
        authorName: String,
        authorAvatarData: String,
        caption: String,
        imageData: String = "",
        bgColorHex: String = "#1877F2"
    ): String {
        val uid = requireUserId()
        val docRef = db.collection("stories").document()
        val payload = mutableMapOf<String, Any>(
            "authorId" to uid,
            "authorName" to authorName.take(80).ifBlank { "Zisan User" },
            "caption" to caption.trim().take(300),
            "bgColorHex" to bgColorHex.take(16).ifBlank { "#1877F2" },
            "visibility" to "public",
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (authorAvatarData.isNotBlank()) payload["authorAvatarData"] = authorAvatarData
        if (imageData.isNotBlank()) payload["imageData"] = imageData

        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // --- Follows ---

    fun observeFollowing(uid: String): Flow<List<Follow>> =
        db.collection("follows")
            .whereEqualTo("followerId", uid)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(Follow::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .logFirestoreErrors(OperationType.LIST, "follows", uid)

    fun observeFollowers(uid: String): Flow<List<Follow>> =
        db.collection("follows")
            .whereEqualTo("targetId", uid)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(Follow::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .logFirestoreErrors(OperationType.LIST, "follows", uid)

    suspend fun toggleFollow(
        targetProfile: PublicProfile,
        currentlyFollowing: Boolean,
        actorName: String,
        actorAvatarData: String
    ) {
        val uid = requireUserId()
        if (targetProfile.userId == uid) return
        val followId = "${uid}_${targetProfile.userId}"
        val docRef = db.collection("follows").document(followId)

        try {
            if (currentlyFollowing) {
                docRef.delete().await()
            } else {
                docRef.set(
                    mapOf(
                        "followerId" to uid,
                        "targetId" to targetProfile.userId,
                        "targetName" to targetProfile.displayName.take(80),
                        "followerName" to actorName.take(80),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                createNotification(
                    recipientId = targetProfile.userId,
                    actorName = actorName,
                    actorAvatarData = actorAvatarData,
                    type = "follow",
                    message = "$actorName started following you."
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // --- Friendships ---

    private fun pairId(uid1: String, uid2: String): Pair<String, Pair<String, String>> {
        val sorted = listOf(uid1, uid2).sorted()
        return "${sorted[0]}_${sorted[1]}" to (sorted[0] to sorted[1])
    }

    fun observeFriendships(uid: String): Flow<List<Friendship>> =
        db.collection("friendships")
            .whereArrayContains("memberUids", uid)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(Friendship::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .logFirestoreErrors(OperationType.LIST, "friendships", uid)

    suspend fun sendFriendRequest(
        targetProfile: PublicProfile,
        actorName: String,
        actorAvatarData: String
    ) {
        val uid = requireUserId()
        if (targetProfile.userId == uid) return
        val (friendshipId, ordered) = pairId(uid, targetProfile.userId)
        val docRef = db.collection("friendships").document(friendshipId)

        try {
            docRef.set(
                mapOf(
                    "userAId" to ordered.first,
                    "userBId" to ordered.second,
                    "memberUids" to listOf(ordered.first, ordered.second),
                    "requesterId" to uid,
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            createNotification(
                recipientId = targetProfile.userId,
                actorName = actorName,
                actorAvatarData = actorAvatarData,
                type = "friend_request",
                message = "$actorName sent you a friend request."
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun acceptFriendRequest(
        friendship: Friendship,
        actorName: String,
        actorAvatarData: String
    ) {
        val uid = requireUserId()
        val docRef = db.collection("friendships").document(friendship.id)
        try {
            docRef.update(
                mapOf(
                    "status" to "accepted",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val otherId = friendship.memberUids.firstOrNull { it != uid }
            if (otherId != null) {
                createNotification(
                    recipientId = otherId,
                    actorName = actorName,
                    actorAvatarData = actorAvatarData,
                    type = "friend_accept",
                    message = "$actorName accepted your friend request."
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun removeFriendship(friendshipId: String) {
        requireUserId()
        val docRef = db.collection("friendships").document(friendshipId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- Messenger Conversations & Messages ---

    fun observeConversations(uid: String): Flow<List<Conversation>> =
        db.collection("conversations")
            .whereArrayContains("memberUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "conversations", uid)

    fun observeMessages(conversationId: String, uid: String): Flow<List<ChatMessage>> =
        db.collection("conversations").document(conversationId).collection("messages")
            .whereArrayContains("memberUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "conversations/$conversationId/messages", uid)

    suspend fun openOrCreateConversation(
        currentProfile: UserAccount,
        otherProfile: PublicProfile
    ): Conversation {
        val uid = requireUserId()
        val (convId, ordered) = pairId(uid, otherProfile.userId)
        val docRef = db.collection("conversations").document(convId)

        try {
            val existingSnap = db.collection("conversations")
                .whereArrayContains("memberUids", uid)
                .get()
                .await()
                .documents
                .firstOrNull { it.id == convId }
            if (existingSnap != null) {
                return existingSnap.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)!!
            }
            val oneIsCurrent = ordered.first == uid
            val p1Name = if (oneIsCurrent) currentProfile.displayName else otherProfile.displayName
            val p1Avatar = if (oneIsCurrent) currentProfile.avatarData else otherProfile.avatarData
            val p2Name = if (oneIsCurrent) otherProfile.displayName else currentProfile.displayName
            val p2Avatar = if (oneIsCurrent) otherProfile.avatarData else currentProfile.avatarData

            val payload = mutableMapOf<String, Any>(
                "memberUids" to listOf(ordered.first, ordered.second),
                "participantOneId" to ordered.first,
                "participantOneName" to p1Name.ifBlank { "Member" }.take(80),
                "participantTwoId" to ordered.second,
                "participantTwoName" to p2Name.ifBlank { "Member" }.take(80),
                "lastMessage" to "",
                "lastSenderId" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (p1Avatar.isNotBlank()) payload["participantOneAvatar"] = p1Avatar
            if (p2Avatar.isNotBlank()) payload["participantTwoAvatar"] = p2Avatar

            docRef.set(payload).await()
            return Conversation(
                id = convId,
                memberUids = listOf(ordered.first, ordered.second),
                participantOneId = ordered.first,
                participantOneName = p1Name.ifBlank { "Member" },
                participantOneAvatar = p1Avatar,
                participantTwoId = ordered.second,
                participantTwoName = p2Name.ifBlank { "Member" },
                participantTwoAvatar = p2Avatar,
                lastMessage = "",
                lastSenderId = uid
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun sendMessage(
        conversation: Conversation,
        senderName: String,
        senderAvatarData: String,
        text: String
    ) {
        val uid = requireUserId()
        val trimmed = text.trim().take(2000)
        if (trimmed.isBlank()) return

        val convRef = db.collection("conversations").document(conversation.id)
        val msgRef = convRef.collection("messages").document()

        try {
            val batch = db.batch()
            batch.set(
                msgRef,
                mapOf(
                    "conversationId" to conversation.id,
                    "senderId" to uid,
                    "senderName" to senderName.take(80).ifBlank { "Member" },
                    "memberUids" to conversation.memberUids,
                    "text" to trimmed,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                convRef,
                mapOf(
                    "lastMessage" to trimmed.take(1000),
                    "lastSenderId" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            val recipientId = conversation.memberUids.firstOrNull { it != uid }
            if (recipientId != null) {
                createNotification(
                    recipientId = recipientId,
                    actorName = senderName,
                    actorAvatarData = senderAvatarData,
                    type = "message",
                    message = "$senderName sent you a message: \"${trimmed.take(50)}\""
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    // --- Notifications ---

    fun observeNotifications(uid: String): Flow<List<NotificationItem>> =
        db.collection("notifications")
            .whereEqualTo("recipientId", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(NotificationItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(OperationType.LIST, "notifications", uid)

    private suspend fun createNotification(
        recipientId: String,
        actorName: String,
        actorAvatarData: String,
        type: String,
        message: String,
        targetPostId: String = ""
    ) {
        val uid = auth.currentUser?.uid ?: return
        if (recipientId == uid || recipientId.isBlank()) return
        val docRef = db.collection("notifications").document()
        val payload = mutableMapOf<String, Any>(
            "recipientId" to recipientId,
            "actorId" to uid,
            "actorName" to actorName.take(80).ifBlank { "Someone" },
            "type" to type,
            "message" to message.take(300),
            "isRead" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (actorAvatarData.isNotBlank()) payload["actorAvatarData"] = actorAvatarData
        if (targetPostId.isNotBlank()) payload["targetPostId"] = targetPostId

        try {
            docRef.set(payload).await()
        } catch (_: Exception) {
            // Best-effort notification delivery; primary action already succeeded
        }
    }

    suspend fun markNotificationRead(notificationId: String) {
        requireUserId()
        val docRef = db.collection("notifications").document(notificationId)
        try {
            docRef.update("isRead", true).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun markAllNotificationsRead(notifications: List<NotificationItem>) {
        requireUserId()
        val unread = notifications.filter { !it.isRead }
        if (unread.isEmpty()) return
        try {
            val batch = db.batch()
            unread.take(400).forEach { item ->
                batch.update(db.collection("notifications").document(item.id), "isRead", true)
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "notifications")
            throw e
        }
    }
}
