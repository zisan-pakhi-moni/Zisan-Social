package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = ZisanBlue,
    onPrimary = ZisanWhite,
    primaryContainer = ZisanBlueSoft,
    onPrimaryContainer = ZisanBlueDark,
    secondary = ZisanGreen,
    onSecondary = ZisanWhite,
    secondaryContainer = ZisanGreenSoft,
    onSecondaryContainer = ZisanGreen,
    tertiary = ZisanBlueDark,
    onTertiary = ZisanWhite,
    background = ZisanFeedBackground,
    onBackground = ZisanInkPrimary,
    surface = ZisanWhite,
    onSurface = ZisanInkPrimary,
    surfaceVariant = ZisanInputBg,
    onSurfaceVariant = ZisanInkSecondary,
    outline = ZisanDivider,
    outlineVariant = ZisanDivider,
    error = ZisanRed,
    onError = ZisanWhite,
    errorContainer = ZisanRedSoft,
    onErrorContainer = ZisanRed
)

private val DarkColorScheme = darkColorScheme(
    primary = ZisanBlueLight,
    onPrimary = ZisanWhite,
    primaryContainer = ZisanBlueDark,
    onPrimaryContainer = ZisanBlueSoft,
    secondary = ZisanGreen,
    onSecondary = ZisanWhite,
    background = ZisanDarkBg,
    onBackground = ZisanDarkInkPrimary,
    surface = ZisanDarkSurface,
    onSurface = ZisanDarkInkPrimary,
    surfaceVariant = ZisanDarkElevated,
    onSurfaceVariant = ZisanDarkInkSecondary,
    outline = ZisanDarkElevated,
    error = ZisanRed,
    onError = ZisanWhite
)

val ZisanShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ZisanSocialTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = ZisanTypography,
        shapes = ZisanShapes,
        content = content
    )
}
