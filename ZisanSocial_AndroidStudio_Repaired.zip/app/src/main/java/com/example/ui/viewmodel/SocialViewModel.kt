package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.Comment
import com.example.data.model.Conversation
import com.example.data.model.Follow
import com.example.data.model.Friendship
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.PublicProfile
import com.example.data.model.Story
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.example.data.repository.SocialRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class SocialViewModel(
    private val repository: SocialRepository,
    val currentUserId: String
) : ViewModel() {

    private fun Throwable.unwrapRootMessage(fallback: String): String {
        val firestoreError = generateSequence(this) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && this is CancellationException) throw this
        val root = firestoreError ?: this
        Log.w(TAG, fallback, root)
        return root.message ?: fallback
    }

    private fun <T> Flow<T>.toUiStateFlow(fallbackError: String): StateFlow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                emit(UiState.Error(error.unwrapRootMessage(fallbackError)))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                initialValue = UiState.Loading
            )

    val userAccountState: StateFlow<UiState<UserAccount?>> =
        repository.observeUserAccount(currentUserId)
            .toUiStateFlow("Failed to load account")

    val feedPostsState: StateFlow<UiState<List<Post>>> =
        repository.observePublicFeedPosts()
            .toUiStateFlow("Failed to load feed")

    val stories: StateFlow<List<Story>> =
        repository.observeStories()
            .catch { err ->
                err.unwrapRootMessage("Failed to load stories")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val publicProfiles: StateFlow<List<PublicProfile>> =
        repository.observePublicProfiles()
            .catch { err ->
                err.unwrapRootMessage("Failed to load profiles")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val likedPostIds: StateFlow<Set<String>> =
        repository.observeLikedPostIds(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load liked posts")
                emit(emptySet())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptySet())

    val following: StateFlow<List<Follow>> =
        repository.observeFollowing(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load following")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val followers: StateFlow<List<Follow>> =
        repository.observeFollowers(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load followers")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val friendships: StateFlow<List<Friendship>> =
        repository.observeFriendships(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load friendships")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val conversations: StateFlow<List<Conversation>> =
        repository.observeConversations(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load conversations")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val notifications: StateFlow<List<NotificationItem>> =
        repository.observeNotifications(currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load notifications")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Active Comments Sheet
    private val _activeCommentsPost = MutableStateFlow<Post?>(null)
    val activeCommentsPost = _activeCommentsPost.asStateFlow()

    val activeComments: StateFlow<List<Comment>> =
        _activeCommentsPost.flatMapLatest { post ->
            if (post == null) flowOf(emptyList())
            else repository.observeComments(post.id).catch { err ->
                err.unwrapRootMessage("Failed to load comments")
                emit(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Active Chat Conversation
    private val _activeConversation = MutableStateFlow<Conversation?>(null)
    val activeConversation = _activeConversation.asStateFlow()

    val activeMessages: StateFlow<List<ChatMessage>> =
        _activeConversation.flatMapLatest { conv ->
            if (conv == null) flowOf(emptyList())
            else repository.observeMessages(conv.id, currentUserId).catch { err ->
                err.unwrapRootMessage("Failed to load messages")
                emit(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // Selected Profile to Inspect
    private val _inspectedProfile = MutableStateFlow<PublicProfile?>(null)
    val inspectedProfile = _inspectedProfile.asStateFlow()

    val inspectedProfilePosts: StateFlow<List<Post>> =
        _inspectedProfile.flatMapLatest { profile ->
            if (profile == null) flowOf(emptyList())
            else repository.observeUserPosts(profile.userId, currentUserId).catch { err ->
                err.unwrapRootMessage("Failed to load user posts")
                emit(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val ownPosts: StateFlow<List<Post>> =
        repository.observeUserPosts(currentUserId, currentUserId)
            .catch { err ->
                err.unwrapRootMessage("Failed to load your posts")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage = _feedbackMessage.asStateFlow()

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    private fun currentActor(): UserAccount {
        return (userAccountState.value as? UiState.Success)?.data
            ?: UserAccount(userId = currentUserId, displayName = "Zisan User", username = "user")
    }

    suspend fun saveProfile(
        displayName: String,
        username: String,
        bio: String,
        city: String,
        avatarData: String,
        email: String
    ) {
        repository.saveUserProfile(
            displayName = displayName,
            username = username,
            bio = bio,
            city = city,
            avatarData = avatarData,
            email = email,
            onboardingCompleted = true
        )
        _feedbackMessage.value = "Profile updated"
    }

    fun createPost(
        content: String,
        imageData: String = "",
        feeling: String = "",
        bgColorHex: String = "",
        visibility: String = "public",
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.createPost(
                    authorName = actor.displayName,
                    authorHandle = actor.username,
                    authorAvatarData = actor.avatarData,
                    content = content,
                    imageData = imageData,
                    feeling = feeling,
                    bgColorHex = bgColorHex,
                    visibility = visibility
                )
                _feedbackMessage.value = "Post shared!"
                onDone()
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to publish post"
            }
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            try {
                repository.deletePost(postId)
                _feedbackMessage.value = "Post deleted"
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Could not delete post"
            }
        }
    }

    fun toggleLike(post: Post) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                val liked = likedPostIds.value.contains(post.id)
                repository.toggleLikePost(
                    post = post,
                    currentlyLiked = liked,
                    actorName = actor.displayName,
                    actorAvatarData = actor.avatarData
                )
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to update like"
            }
        }
    }

    fun openComments(post: Post) {
        _activeCommentsPost.value = post
    }

    fun closeComments() {
        _activeCommentsPost.value = null
    }

    fun addComment(post: Post, text: String) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.addComment(
                    post = post,
                    authorName = actor.displayName,
                    authorAvatarData = actor.avatarData,
                    text = text
                )
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to post comment"
            }
        }
    }

    fun sharePost(post: Post, note: String) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.sharePost(
                    originalPost = post,
                    sharerName = actor.displayName,
                    sharerHandle = actor.username,
                    sharerAvatarData = actor.avatarData,
                    note = note
                )
                _feedbackMessage.value = "Shared to your feed!"
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to share post"
            }
        }
    }

    fun createStory(
        caption: String,
        imageData: String = "",
        bgColorHex: String = "#1877F2",
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.createStory(
                    authorName = actor.displayName,
                    authorAvatarData = actor.avatarData,
                    caption = caption,
                    imageData = imageData,
                    bgColorHex = bgColorHex
                )
                _feedbackMessage.value = "Story published!"
                onDone()
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to add story"
            }
        }
    }

    fun toggleFollow(target: PublicProfile) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                val isFollowing = following.value.any { it.targetId == target.userId }
                repository.toggleFollow(
                    targetProfile = target,
                    currentlyFollowing = isFollowing,
                    actorName = actor.displayName,
                    actorAvatarData = actor.avatarData
                )
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to update follow"
            }
        }
    }

    fun sendFriendRequest(target: PublicProfile) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.sendFriendRequest(target, actor.displayName, actor.avatarData)
                _feedbackMessage.value = "Friend request sent to ${target.displayName}"
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Could not send request"
            }
        }
    }

    fun acceptFriendRequest(friendship: Friendship) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.acceptFriendRequest(friendship, actor.displayName, actor.avatarData)
                _feedbackMessage.value = "You are now friends!"
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Could not accept request"
            }
        }
    }

    fun removeFriendship(friendshipId: String) {
        viewModelScope.launch {
            try {
                repository.removeFriendship(friendshipId)
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Could not update friend status"
            }
        }
    }

    fun openChatWith(otherProfile: PublicProfile) {
        viewModelScope.launch {
            try {
                val actor = currentActor()
                val conv = repository.openOrCreateConversation(actor, otherProfile)
                _activeConversation.value = conv
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Could not open chat"
            }
        }
    }

    fun openConversation(conversation: Conversation) {
        _activeConversation.value = conversation
    }

    fun closeConversation() {
        _activeConversation.value = null
    }

    fun sendMessage(text: String) {
        val conv = _activeConversation.value ?: return
        viewModelScope.launch {
            try {
                val actor = currentActor()
                repository.sendMessage(conv, actor.displayName, actor.avatarData, text)
            } catch (e: Exception) {
                _feedbackMessage.value = e.localizedMessage ?: "Failed to send message"
            }
        }
    }

    fun inspectProfile(profile: PublicProfile) {
        _inspectedProfile.value = profile
    }

    fun inspectProfileById(uid: String) {
        val match = publicProfiles.value.firstOrNull { it.userId == uid }
        if (match != null) {
            _inspectedProfile.value = match
        }
    }

    fun closeInspectedProfile() {
        _inspectedProfile.value = null
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            try {
                repository.markNotificationRead(notificationId)
            } catch (_: Exception) { }
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            try {
                repository.markAllNotificationsRead(notifications.value)
            } catch (_: Exception) { }
        }
    }

    private companion object {
        const val TAG = "SocialViewModel"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
