package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Follow
import com.example.data.model.Friendship
import com.example.data.model.Post
import com.example.data.model.PublicProfile
import com.example.data.model.UserAccount
import com.example.data.util.ImageEncodingUtils
import com.example.ui.components.PostCard
import com.example.ui.components.UserAvatar
import com.example.ui.theme.ZisanBlue
import com.example.ui.theme.ZisanBlueSoft
import com.example.ui.theme.ZisanWhite
import kotlinx.coroutines.launch

@Composable
fun OwnProfileScreen(
    account: UserAccount?,
    posts: List<Post>,
    friendsCount: Int,
    followersCount: Int,
    followingCount: Int,
    likedPostIds: Set<String>,
    onCreatePost: () -> Unit,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit,
    onLikeClick: (Post) -> Unit,
    onCommentClick: (Post) -> Unit,
    onShareClick: (Post) -> Unit,
    onDeletePost: (Post) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item(key = "own_profile_header") {
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Image(
                                painter = painterResource(id = R.drawable.img_cover_default),
                                contentDescription = "Profile cover photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(155.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .padding(start = 16.dp)
                                    .offset(y = 104.dp)
                                    .border(4.dp, MaterialTheme.colorScheme.surface, CircleShape)
                            ) {
                                UserAvatar(
                                    avatarData = account?.avatarData ?: "",
                                    displayName = account?.displayName ?: "Z",
                                    size = 98.dp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(54.dp))

                        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                            Text(
                                text = account?.displayName ?: "Zisan Member",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (!account?.username.isNullOrBlank()) {
                                Text(
                                    text = "@${account?.username}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ZisanBlue,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            if (!account?.bio.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = account?.bio ?: "",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            if (!account?.city.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.LocationOn,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Lives in ${account?.city}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Stats Bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                StatPill(value = posts.size, label = "Posts")
                                StatPill(value = friendsCount, label = "Friends")
                                StatPill(value = followersCount, label = "Followers")
                                StatPill(value = followingCount, label = "Following")
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onCreatePost,
                                    colors = ButtonDefaults.buttonColors(containerColor = ZisanBlue, contentColor = ZisanWhite),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Post")
                                }
                                OutlinedButton(
                                    onClick = onEditProfile,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("edit_profile_button")
                                ) {
                                    Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit Profile")
                                }
                                IconButton(
                                    onClick = onSignOut,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .testTag("sign_out_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                                        contentDescription = "Sign out",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }
                    }
                }
            }

            if (posts.isEmpty()) {
                item(key = "own_posts_empty") {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "You haven't posted yet. Tap 'Add Post' to share your first update!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(posts, key = { it.id }) { post ->
                    PostCard(
                        post = post,
                        isLiked = likedPostIds.contains(post.id),
                        isOwnPost = true,
                        onAuthorClick = {},
                        onLikeClick = { onLikeClick(post) },
                        onCommentClick = { onCommentClick(post) },
                        onShareClick = { onShareClick(post) },
                        onDeleteClick = { onDeletePost(post) }
                    )
                }
            }
        }
    }
}

@Composable
fun PublicProfileDetailScreen(
    profile: PublicProfile,
    currentUserId: String,
    posts: List<Post>,
    friendship: Friendship?,
    isFollowing: Boolean,
    likedPostIds: Set<String>,
    onBack: () -> Unit,
    onAddFriend: () -> Unit,
    onAcceptFriend: () -> Unit,
    onRemoveFriendship: () -> Unit,
    onToggleFollow: () -> Unit,
    onMessageClick: () -> Unit,
    onLikeClick: (Post) -> Unit,
    onCommentClick: (Post) -> Unit,
    onShareClick: (Post) -> Unit
) {
    BackHandler { onBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = ZisanBlue)
                    }
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(key = "public_header") {
                    Surface(color = MaterialTheme.colorScheme.surface) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_cover_default),
                                    contentDescription = "Cover photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(145.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .padding(start = 16.dp)
                                        .offset(y = 95.dp)
                                        .border(4.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                ) {
                                    UserAvatar(
                                        avatarData = profile.avatarData,
                                        displayName = profile.displayName,
                                        size = 92.dp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(50.dp))
                            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                                Text(
                                    text = profile.displayName,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "@${profile.username}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ZisanBlue
                                )
                                if (profile.bio.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = profile.bio, style = MaterialTheme.typography.bodyMedium)
                                }
                                if (profile.city.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Lives in ${profile.city}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    when {
                                        friendship == null -> {
                                            Button(
                                                onClick = onAddFriend,
                                                colors = ButtonDefaults.buttonColors(containerColor = ZisanBlue, contentColor = ZisanWhite),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Add Friend")
                                            }
                                        }
                                        friendship.status == "pending" && friendship.requesterId == currentUserId -> {
                                            OutlinedButton(onClick = onRemoveFriendship, modifier = Modifier.weight(1f)) {
                                                Text("Requested")
                                            }
                                        }
                                        friendship.status == "pending" -> {
                                            Button(onClick = onAcceptFriend, modifier = Modifier.weight(1f)) {
                                                Text("Accept Request")
                                            }
                                        }
                                        else -> {
                                            Button(
                                                onClick = onMessageClick,
                                                colors = ButtonDefaults.buttonColors(containerColor = ZisanBlueSoft, contentColor = ZisanBlue),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Message")
                                            }
                                        }
                                    }
                                    OutlinedButton(onClick = onToggleFollow) {
                                        Text(if (isFollowing) "Following" else "Follow")
                                    }
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                            }
                        }
                    }
                }

                items(posts, key = { it.id }) { post ->
                    PostCard(
                        post = post,
                        isLiked = likedPostIds.contains(post.id),
                        isOwnPost = post.authorId == currentUserId,
                        onAuthorClick = {},
                        onLikeClick = { onLikeClick(post) },
                        onCommentClick = { onCommentClick(post) },
                        onShareClick = { onShareClick(post) },
                        onDeleteClick = {}
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileSheet(
    account: UserAccount?,
    onDismiss: () -> Unit,
    onSave: (displayName: String, username: String, bio: String, city: String, avatarData: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var displayName by remember { mutableStateOf(account?.displayName ?: "") }
    var username by remember { mutableStateOf(account?.username ?: "") }
    var bio by remember { mutableStateOf(account?.bio ?: "") }
    var city by remember { mutableStateOf(account?.city ?: "") }
    var avatarData by remember { mutableStateOf(account?.avatarData ?: "") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = ImageEncodingUtils.encodeUriToCompactBase64(context, uri, maxDimension = 320, quality = 65)
                if (encoded != null) avatarData = encoded
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Edit Profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .clickable {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
            ) {
                UserAvatar(avatarData = avatarData, displayName = displayName.ifBlank { "Z" }, size = 88.dp)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(ZisanBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.CameraAlt, contentDescription = "Change avatar", tint = ZisanWhite, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it },
                label = { Text("Display Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = username,
                onValueChange = { username = it.lowercase().replace(" ", "") },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                label = { Text("City") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it.take(250) },
                label = { Text("Bio") },
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { onSave(displayName, username, bio, city, avatarData) },
                enabled = displayName.isNotBlank() && username.length >= 2,
                colors = ButtonDefaults.buttonColors(containerColor = ZisanBlue, contentColor = ZisanWhite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Save Changes")
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatPill(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = ZisanBlue
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
