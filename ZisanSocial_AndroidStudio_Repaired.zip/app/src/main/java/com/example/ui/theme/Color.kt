package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Zisan Social — Facebook-inspired Cobalt Blue & Crisp White Palette
val ZisanBlue = Color(0xFF1877F2)
val ZisanBlueDark = Color(0xFF0F5AC2)
val ZisanBlueSoft = Color(0xFFE7F3FF)
val ZisanBlueTint = Color(0xFFD8E8FF)

val ZisanWhite = Color(0xFFFFFFFF)
val ZisanFeedBackground = Color(0xFFF0F2F5)
val ZisanDivider = Color(0xFFE4E6EB)
val ZisanInputBg = Color(0xFFF0F2F5)

val ZisanInkPrimary = Color(0xFF050505)
val ZisanInkSecondary = Color(0xFF65676B)
val ZisanInkMuted = Color(0xFF8A8D91)

val ZisanGreen = Color(0xFF42B72A)
val ZisanGreenSoft = Color(0xFFE7F6E5)
val ZisanRed = Color(0xFFFA383E)
val ZisanRedSoft = Color(0xFFFFEBEE)
val ZisanAmber = Color(0xFFF7B928)

// Dark Mode Tokens
val ZisanDarkBg = Color(0xFF18191A)
val ZisanDarkSurface = Color(0xFF242526)
val ZisanDarkElevated = Color(0xFF3A3B3C)
val ZisanDarkInkPrimary = Color(0xFFE4E6EB)
val ZisanDarkInkSecondary = Color(0xFFB0B3B8)
val ZisanBlueLight = Color(0xFF4599FF)
