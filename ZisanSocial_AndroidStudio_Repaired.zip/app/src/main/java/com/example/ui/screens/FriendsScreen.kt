package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.Follow
import com.example.data.model.Friendship
import com.example.data.model.PublicProfile
import com.example.ui.components.UserAvatar
import com.example.ui.theme.ZisanBlue
import com.example.ui.theme.ZisanBlueSoft
import com.example.ui.theme.ZisanGreen
import com.example.ui.theme.ZisanWhite

private enum class PeopleFilter(val label: String) {
    ALL("Discover"),
    REQUESTS("Requests"),
    FRIENDS("Friends"),
    FOLLOWING("Following")
}

@Composable
fun FriendsScreen(
    currentUserId: String,
    profiles: List<PublicProfile>,
    following: List<Follow>,
    friendships: List<Friendship>,
    onProfileClick: (PublicProfile) -> Unit,
    onAddFriend: (PublicProfile) -> Unit,
    onAcceptFriend: (Friendship) -> Unit,
    onRemoveFriendship: (String) -> Unit,
    onToggleFollow: (PublicProfile) -> Unit,
    onMessageClick: (PublicProfile) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(PeopleFilter.ALL) }

    val otherProfiles = remember(profiles, currentUserId) {
        profiles.filter { it.userId != currentUserId }
    }
    val followingIds = remember(following) { following.map { it.targetId }.toSet() }
    val incomingRequestsCount = remember(friendships, currentUserId) {
        friendships.count { it.status == "pending" && it.requesterId != currentUserId }
    }

    val filteredProfiles = remember(otherProfiles, friendships, followingIds, query, filter, currentUserId) {
        otherProfiles.filter { profile ->
            val matchesSearch = query.isBlank() ||
                profile.displayName.contains(query, ignoreCase = true) ||
                profile.username.contains(query, ignoreCase = true) ||
                profile.city.contains(query, ignoreCase = true)
            if (!matchesSearch) return@filter false

            val friendship = friendships.firstOrNull { profile.userId in it.memberUids }
            when (filter) {
                PeopleFilter.ALL -> true
                PeopleFilter.REQUESTS -> friendship?.status == "pending" && friendship.requesterId != currentUserId
                PeopleFilter.FRIENDS -> friendship?.status == "accepted"
                PeopleFilter.FOLLOWING -> followingIds.contains(profile.userId)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Text(
                        text = "Friends & People",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search people by name, @handle, or city") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PeopleFilter.entries) { entry ->
                            val label = if (entry == PeopleFilter.REQUESTS && incomingRequestsCount > 0) {
                                "${entry.label} ($incomingRequestsCount)"
                            } else entry.label
                            FilterChip(
                                selected = filter == entry,
                                onClick = { filter = entry },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            if (filteredProfiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Rounded.Groups,
                            contentDescription = null,
                            tint = ZisanBlue,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = when (filter) {
                                PeopleFilter.REQUESTS -> "No pending friend requests"
                                PeopleFilter.FRIENDS -> "No friends added yet"
                                PeopleFilter.FOLLOWING -> "You aren't following anyone yet"
                                PeopleFilter.ALL -> "No other members found yet"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "As more people join Zisan Social, they'll appear here to connect, follow, and chat.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredProfiles, key = { it.userId }) { profile ->
                        val friendship = friendships.firstOrNull { profile.userId in it.memberUids }
                        val isFollowing = followingIds.contains(profile.userId)
                        PersonCard(
                            profile = profile,
                            currentUserId = currentUserId,
                            friendship = friendship,
                            isFollowing = isFollowing,
                            onProfileClick = { onProfileClick(profile) },
                            onAddFriend = { onAddFriend(profile) },
                            onAcceptFriend = { if (friendship != null) onAcceptFriend(friendship) },
                            onRemoveFriendship = { if (friendship != null) onRemoveFriendship(friendship.id) },
                            onToggleFollow = { onToggleFollow(profile) },
                            onMessageClick = { onMessageClick(profile) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonCard(
    profile: PublicProfile,
    currentUserId: String,
    friendship: Friendship?,
    isFollowing: Boolean,
    onProfileClick: () -> Unit,
    onAddFriend: () -> Unit,
    onAcceptFriend: () -> Unit,
    onRemoveFriendship: () -> Unit,
    onToggleFollow: () -> Unit,
    onMessageClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onProfileClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(
                    avatarData = profile.avatarData,
                    displayName = profile.displayName,
                    size = 54.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = buildString {
                            append("@${profile.username}")
                            if (profile.city.isNotBlank()) append(" · ${profile.city}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (profile.bio.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = profile.bio,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when {
                    friendship == null -> {
                        Button(
                            onClick = onAddFriend,
                            colors = ButtonDefaults.buttonColors(containerColor = ZisanBlue, contentColor = ZisanWhite),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Friend")
                        }
                    }

                    friendship.status == "pending" && friendship.requesterId == currentUserId -> {
                        OutlinedButton(
                            onClick = onRemoveFriendship,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel Request")
                        }
                    }

                    friendship.status == "pending" -> {
                        Button(
                            onClick = onAcceptFriend,
                            colors = ButtonDefaults.buttonColors(containerColor = ZisanGreen, contentColor = ZisanWhite),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Confirm")
                        }
                        OutlinedButton(
                            onClick = onRemoveFriendship,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Decline")
                        }
                    }

                    else -> {
                        Button(
                            onClick = onMessageClick,
                            colors = ButtonDefaults.buttonColors(containerColor = ZisanBlueSoft, contentColor = ZisanBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Message")
                        }
                    }
                }

                OutlinedButton(
                    onClick = onToggleFollow,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (isFollowing) "Following" else "Follow")
                }
            }
        }
    }
}
