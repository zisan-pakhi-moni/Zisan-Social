package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UiState
import com.example.data.repository.SocialRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.GoogleSignInHelper
import com.example.ui.auth.ProfileSetupScreen
import com.example.ui.screens.CommentsSheet
import com.example.ui.screens.CreatePostSheet
import com.example.ui.screens.CreateStorySheet
import com.example.ui.screens.EditProfileSheet
import com.example.ui.screens.FeedScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.MessengerScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.OwnProfileScreen
import com.example.ui.screens.PublicProfileDetailScreen
import com.example.ui.screens.SharePostDialog
import com.example.ui.screens.StoryViewerDialog
import com.example.ui.theme.ZisanBlue
import com.example.ui.theme.ZisanBlueSoft
import com.example.ui.theme.ZisanSocialTheme
import com.example.ui.viewmodel.SocialViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZisanSocialTheme {
                AppNavigation()
            }
        }
    }
}

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

private enum class SocialTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    FEED("feed", "Feed", Icons.Filled.Home, Icons.Outlined.Home),
    FRIENDS("friends", "Friends", Icons.Filled.Group, Icons.Outlined.Group),
    CHATS("chats", "Chats", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline),
    ALERTS("alerts", "Alerts", Icons.Filled.Notifications, Icons.Outlined.Notifications),
    PROFILE("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            AuthenticatedSocialShell(currentUserId = user.uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedSocialShell(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: SocialViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val db = FirebaseFirestore.getInstance()
                SocialViewModel(SocialRepository(db, Firebase.auth), currentUserId)
            }
        }
    )

    val accountState by viewModel.userAccountState.collectAsStateWithLifecycle()
    val feedPostsState by viewModel.feedPostsState.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val profiles by viewModel.publicProfiles.collectAsStateWithLifecycle()
    val likedPostIds by viewModel.likedPostIds.collectAsStateWithLifecycle()
    val following by viewModel.following.collectAsStateWithLifecycle()
    val followers by viewModel.followers.collectAsStateWithLifecycle()
    val friendships by viewModel.friendships.collectAsStateWithLifecycle()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val activeCommentsPost by viewModel.activeCommentsPost.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()
    val activeConversation by viewModel.activeConversation.collectAsStateWithLifecycle()
    val activeMessages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val inspectedProfile by viewModel.inspectedProfile.collectAsStateWithLifecycle()
    val inspectedProfilePosts by viewModel.inspectedProfilePosts.collectAsStateWithLifecycle()
    val ownPosts by viewModel.ownPosts.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    when (val acct = accountState) {
        is UiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = ZisanBlue)
            }
            return
        }

        is UiState.Error -> {
            ProfileSetupScreen(
                existingAccount = null,
                onSaveProfile = { name, username, bio, city, avatar, email ->
                    viewModel.saveProfile(name, username, bio, city, avatar, email)
                },
                onSignOut = {
                    GoogleSignInHelper.signOut(credentialManager, scope)
                }
            )
            return
        }

        is UiState.Success -> {
            val account = acct.data
            if (account == null || !account.onboardingCompleted) {
                ProfileSetupScreen(
                    existingAccount = account,
                    onSaveProfile = { name, username, bio, city, avatar, email ->
                        viewModel.saveProfile(name, username, bio, city, avatar, email)
                    },
                    onSignOut = {
                        GoogleSignInHelper.signOut(credentialManager, scope)
                    }
                )
                return
            }
        }
    }

    val currentAccount = (accountState as? UiState.Success)?.data
    var selectedTab by remember { mutableStateOf(SocialTab.FEED) }
    var showCreatePost by remember { mutableStateOf(false) }
    var startPostWithPhoto by remember { mutableStateOf(false) }
    var showCreateStory by remember { mutableStateOf(false) }
    var viewingStory by remember { mutableStateOf<Story?>(null) }
    var sharingPost by remember { mutableStateOf<Post?>(null) }
    var showEditProfile by remember { mutableStateOf(false) }

    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }
    val pendingRequests = remember(friendships, currentUserId) {
        friendships.count { it.status == "pending" && it.requesterId != currentUserId }
    }
    val acceptedFriendsCount = remember(friendships) {
        friendships.count { it.status == "accepted" }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            contentWindowInsets = WindowInsets.navigationBars,
            topBar = {
                if (activeConversation == null && inspectedProfile == null) {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = ZisanBlue
                        ),
                        title = {
                            Text(
                                text = "zisan",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = ZisanBlue
                            )
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    startPostWithPhoto = false
                                    showCreatePost = true
                                },
                                modifier = Modifier.testTag("topbar_create_post_button")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = "Create post", tint = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                            IconButton(
                                onClick = { selectedTab = SocialTab.CHATS },
                                modifier = Modifier.testTag("topbar_messenger_button")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Rounded.ChatBubbleOutline,
                                        contentDescription = "Open Messenger",
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (!useRail && activeConversation == null && inspectedProfile == null) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        SocialTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            val badgeCount = when (tab) {
                                SocialTab.FRIENDS -> pendingRequests
                                SocialTab.ALERTS -> unreadNotifications
                                else -> 0
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (badgeCount > 0) {
                                                Badge { Text(badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    }
                                },
                                label = { Text(tab.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ZisanBlue,
                                    selectedTextColor = ZisanBlue,
                                    indicatorColor = ZisanBlueSoft
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && activeConversation == null && inspectedProfile == null) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.size(12.dp))
                        SocialTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    val inspected = inspectedProfile
                    if (inspected != null) {
                        val friendship = friendships.firstOrNull { inspected.userId in it.memberUids }
                        val isFollowing = following.any { it.targetId == inspected.userId }
                        PublicProfileDetailScreen(
                            profile = inspected,
                            currentUserId = currentUserId,
                            posts = inspectedProfilePosts,
                            friendship = friendship,
                            isFollowing = isFollowing,
                            likedPostIds = likedPostIds,
                            onBack = { viewModel.closeInspectedProfile() },
                            onAddFriend = { viewModel.sendFriendRequest(inspected) },
                            onAcceptFriend = { if (friendship != null) viewModel.acceptFriendRequest(friendship) },
                            onRemoveFriendship = { if (friendship != null) viewModel.removeFriendship(friendship.id) },
                            onToggleFollow = { viewModel.toggleFollow(inspected) },
                            onMessageClick = {
                                viewModel.closeInspectedProfile()
                                selectedTab = SocialTab.CHATS
                                viewModel.openChatWith(inspected)
                            },
                            onLikeClick = { viewModel.toggleLike(it) },
                            onCommentClick = { viewModel.openComments(it) },
                            onShareClick = { sharingPost = it }
                        )
                    } else {
                        when (selectedTab) {
                            SocialTab.FEED -> FeedScreen(
                                currentUser = currentAccount,
                                currentUserId = currentUserId,
                                feedPostsState = feedPostsState,
                                stories = stories,
                                likedPostIds = likedPostIds,
                                onOpenCreatePost = { withPhoto ->
                                    startPostWithPhoto = withPhoto
                                    showCreatePost = true
                                },
                                onOpenCreateStory = { showCreateStory = true },
                                onStoryClick = { viewingStory = it },
                                onAuthorClick = { uid ->
                                    if (uid == currentUserId) selectedTab = SocialTab.PROFILE
                                    else viewModel.inspectProfileById(uid)
                                },
                                onLikeClick = { viewModel.toggleLike(it) },
                                onCommentClick = { viewModel.openComments(it) },
                                onShareClick = { sharingPost = it },
                                onDeleteClick = { viewModel.deletePost(it.id) }
                            )

                            SocialTab.FRIENDS -> FriendsScreen(
                                currentUserId = currentUserId,
                                profiles = profiles,
                                following = following,
                                friendships = friendships,
                                onProfileClick = { viewModel.inspectProfile(it) },
                                onAddFriend = { viewModel.sendFriendRequest(it) },
                                onAcceptFriend = { viewModel.acceptFriendRequest(it) },
                                onRemoveFriendship = { viewModel.removeFriendship(it) },
                                onToggleFollow = { viewModel.toggleFollow(it) },
                                onMessageClick = {
                                    selectedTab = SocialTab.CHATS
                                    viewModel.openChatWith(it)
                                }
                            )

                            SocialTab.CHATS -> MessengerScreen(
                                currentUserId = currentUserId,
                                profiles = profiles,
                                conversations = conversations,
                                activeConversation = activeConversation,
                                activeMessages = activeMessages,
                                onStartChatWith = { viewModel.openChatWith(it) },
                                onOpenConversation = { viewModel.openConversation(it) },
                                onCloseConversation = { viewModel.closeConversation() },
                                onSendMessage = { viewModel.sendMessage(it) }
                            )

                            SocialTab.ALERTS -> NotificationsScreen(
                                notifications = notifications,
                                onNotificationClick = { item ->
                                    viewModel.markNotificationRead(item.id)
                                    when (item.type) {
                                        "message" -> selectedTab = SocialTab.CHATS
                                        "friend_request", "friend_accept", "follow" -> selectedTab = SocialTab.FRIENDS
                                        else -> selectedTab = SocialTab.FEED
                                    }
                                },
                                onMarkAllRead = { viewModel.markAllNotificationsRead() }
                            )

                            SocialTab.PROFILE -> OwnProfileScreen(
                                account = currentAccount,
                                posts = ownPosts,
                                friendsCount = acceptedFriendsCount,
                                followersCount = followers.size,
                                followingCount = following.size,
                                likedPostIds = likedPostIds,
                                onCreatePost = {
                                    startPostWithPhoto = false
                                    showCreatePost = true
                                },
                                onEditProfile = { showEditProfile = true },
                                onSignOut = {
                                    GoogleSignInHelper.signOut(credentialManager, scope)
                                },
                                onLikeClick = { viewModel.toggleLike(it) },
                                onCommentClick = { viewModel.openComments(it) },
                                onShareClick = { sharingPost = it },
                                onDeletePost = { viewModel.deletePost(it.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Overlays
    if (showCreatePost) {
        CreatePostSheet(
            currentUser = currentAccount,
            startWithPhoto = startPostWithPhoto,
            onDismiss = { showCreatePost = false },
            onPublish = { content, img, feeling, bg, vis ->
                viewModel.createPost(content, img, feeling, bg, vis) {
                    showCreatePost = false
                }
            }
        )
    }

    if (showCreateStory) {
        CreateStorySheet(
            onDismiss = { showCreateStory = false },
            onPublish = { caption, img, bg ->
                viewModel.createStory(caption, img, bg) {
                    showCreateStory = false
                }
            }
        )
    }

    val storyToView = viewingStory
    if (storyToView != null) {
        StoryViewerDialog(
            story = storyToView,
            onDismiss = { viewingStory = null }
        )
    }

    val commentsPost = activeCommentsPost
    if (commentsPost != null) {
        CommentsSheet(
            post = commentsPost,
            comments = activeComments,
            onDismiss = { viewModel.closeComments() },
            onSendComment = { text -> viewModel.addComment(commentsPost, text) }
        )
    }

    val postToShare = sharingPost
    if (postToShare != null) {
        SharePostDialog(
            post = postToShare,
            onDismiss = { sharingPost = null },
            onConfirmShare = { note ->
                viewModel.sharePost(postToShare, note)
                sharingPost = null
            }
        )
    }

    if (showEditProfile) {
        EditProfileSheet(
            account = currentAccount,
            onDismiss = { showEditProfile = false },
            onSave = { displayName, username, bio, city, avatarData ->
                scope.launch {
                    viewModel.saveProfile(
                        displayName = displayName,
                        username = username,
                        bio = bio,
                        city = city,
                        avatarData = avatarData,
                        email = Firebase.auth.currentUser?.email ?: ""
                    )
                    showEditProfile = false
                }
            }
        )
    }
}
