const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-zisansoc-3b161887-73fb-4c3f-a6ab-6bfcf1d09613";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const nowTs = () => new Date();

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function dbFor(uid) {
  return uid
    ? testEnv.authenticatedContext(uid).firestore(DATABASE_ID)
    : testEnv.unauthenticatedContext().firestore(DATABASE_ID);
}

test("Unauthenticated user cannot read or list posts or users", async () => {
  const unauth = dbFor(null);
  await assertFails(unauth.collection("posts").where("visibility", "==", "public").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("public_profiles").where("isDiscoverable", "==", true).get());
});

test("User PII isolation: Bob cannot read Alice private user doc", async () => {
  const aliceDb = dbFor(ALICE_UID);
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      username: "alice_z",
      onboardingCompleted: true,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  const bobDb = dbFor(BOB_UID);
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
});

test("Shadow field injection rejected on public_profiles", async () => {
  const aliceDb = dbFor(ALICE_UID);
  await assertFails(
    aliceDb.collection("public_profiles").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      username: "alice_z",
      isDiscoverable: true,
      isAdmin: true,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );
});

test("Post creation, public list query alignment, and author isolation on delete", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const bobDb = dbFor(BOB_UID);

  await assertSucceeds(
    aliceDb.collection("posts").doc("post_1").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      content: "Hello Zisan Social!",
      visibility: "public",
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  // Unfiltered list fails (rules are not filters)
  await assertFails(bobDb.collection("posts").get());

  // Aligned public feed query succeeds
  await assertSucceeds(bobDb.collection("posts").where("visibility", "==", "public").get());

  // Bob cannot delete Alice's post
  await assertFails(bobDb.collection("posts").doc("post_1").delete());

  // Bob cannot spoof authorId
  await assertFails(
    bobDb.collection("posts").doc("post_spoof").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      content: "Spoofed!",
      visibility: "public",
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );
});

test("Post like & comment engagement updates and immutability checks", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const bobDb = dbFor(BOB_UID);

  await assertSucceeds(
    aliceDb.collection("posts").doc("post_2").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      content: "Post two",
      visibility: "public",
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  await assertSucceeds(
    bobDb.collection("posts").doc("post_2").collection("likes").doc(BOB_UID).set({
      userId: BOB_UID,
      userName: "Bob",
      postId: "post_2",
      createdAt: nowTs(),
    })
  );

  await assertSucceeds(
    bobDb.collection("posts").doc("post_2").update({
      likesCount: 1,
      updatedAt: nowTs(),
    })
  );

  // Bob cannot edit Alice's post content
  await assertFails(
    bobDb.collection("posts").doc("post_2").update({
      content: "Hacked!",
      updatedAt: nowTs(),
    })
  );

  // Bob can comment on existing post
  await assertSucceeds(
    bobDb.collection("posts").doc("post_2").collection("comments").doc("c1").set({
      postId: "post_2",
      authorId: BOB_UID,
      authorName: "Bob",
      text: "Great post!",
      createdAt: nowTs(),
    })
  );
});

test("Friendships and Messenger conversations isolate non-members", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const bobDb = dbFor(BOB_UID);
  const charlieDb = dbFor(CHARLIE_UID);

  const convId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      memberUids: [ALICE_UID, BOB_UID],
      participantOneId: ALICE_UID,
      participantOneName: "Alice",
      participantTwoId: BOB_UID,
      participantTwoName: "Bob",
      lastMessage: "Hi Bob!",
      lastSenderId: ALICE_UID,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m1").set({
      conversationId: convId,
      senderId: ALICE_UID,
      senderName: "Alice",
      memberUids: [ALICE_UID, BOB_UID],
      text: "Hi Bob!",
      createdAt: nowTs(),
    })
  );

  // Bob can list his conversations & messages
  await assertSucceeds(bobDb.collection("conversations").where("memberUids", "array-contains", BOB_UID).get());
  await assertSucceeds(
    bobDb.collection("conversations").doc(convId).collection("messages").where("memberUids", "array-contains", BOB_UID).get()
  );

  // Charlie cannot read Alice-Bob conversation or messages
  await assertFails(charlieDb.collection("conversations").doc(convId).get());
  await assertFails(charlieDb.collection("conversations").doc(convId).collection("messages").doc("m1").get());
});

test("Notifications strictly enforce recipient isolation on read/update", async () => {
  const aliceDb = dbFor(ALICE_UID);
  const bobDb = dbFor(BOB_UID);

  await assertSucceeds(
    aliceDb.collection("notifications").doc("n1").set({
      recipientId: BOB_UID,
      actorId: ALICE_UID,
      actorName: "Alice",
      type: "like",
      message: "Alice liked your post",
      targetPostId: "p1",
      isRead: false,
      createdAt: nowTs(),
    })
  );

  // Alice cannot read Bob's notification
  await assertFails(aliceDb.collection("notifications").doc("n1").get());

  // Bob can query and mark as read
  await assertSucceeds(bobDb.collection("notifications").where("recipientId", "==", BOB_UID).get());
  await assertSucceeds(bobDb.collection("notifications").doc("n1").update({ isRead: true }));
});
