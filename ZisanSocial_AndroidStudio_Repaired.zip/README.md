# Zisan Social — repaired Android Studio project

## Project identity
- App display name: Zisan Social
- Android application ID (installed package): `com.zisan.social`
- Kotlin/Android resource namespace: `com.example` (intentionally retained because the existing source files and generated `R` references use `com.example`).
- UI: Kotlin + Jetpack Compose
- Backend integration present in source: Firebase Authentication and Cloud Firestore
- Firebase Storage SDK dependency: added in this repair; media upload implementation still needs to be wired into the repository/UI.

## Open in Android Studio
1. Extract this ZIP to a normal folder.
2. In Android Studio choose **Open** and select the extracted `Zisan Social` folder (the folder containing `settings.gradle.kts`).
3. Use JDK 17 or newer (JDK 21 is suitable). Allow Android Studio to download the Android Gradle Plugin, Gradle distribution, and dependencies.
4. Install Android SDK Platform 36 if Android Studio requests it.
5. Wait for Gradle Sync. Then choose **Build > Make Project**.
6. To create a debug APK choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important build note
The original archive contained `gradle-wrapper.properties` but did not contain `gradle-wrapper.jar` or the `gradlew` launcher scripts. This repaired archive preserves the Gradle distribution configuration, but does not fabricate a wrapper JAR. Open the project from Android Studio so the IDE can sync it using its Gradle integration. If you want command-line wrapper launchers, generate them from Android Studio/Gradle after the first successful sync (`gradle wrapper`).

## Firebase setup
- `app/google-services.json` is included from the supplied project. It identifies a Firebase Android app registered for `com.zisan.social`.
- Confirm the Firebase project is yours and that Email/Password and/or Google sign-in providers are enabled in Firebase Console.
- Confirm the configured Firestore database exists and publish `firestore.rules` to the intended database. The `firebase.json` database identifier should be checked against the actual Firebase project before deployment.
- Firebase Storage dependency is included, but Storage bucket setup, Storage Security Rules, and upload code still need to be completed before photo/video uploads work.
- Restrict the Firebase API key in Google Cloud Console to the required Android package and signing certificate(s). Do not commit private service-account keys or upload keystores.

## What was repaired
- Preserved the existing Kotlin package structure to avoid breaking imports and `R` references.
- Explicitly documented the distinction between `namespace` (`com.example`) and `applicationId` (`com.zisan.social`).
- Added Firebase Storage SDK to the version catalog and app dependencies.
- Added this setup guide and kept the existing app source, assets, Firebase configuration, and Firestore rules.

## Verification status
This environment does not have Android SDK/Gradle installed and cannot access the network, so an actual Gradle sync, Kotlin compilation, emulator run, or APK build could not be executed here. The project is prepared for Android Studio sync, but should not be considered build-verified until those steps pass on your machine.
